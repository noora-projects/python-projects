from django.contrib import admin

from movieapp.models import Movies

# Register your models here.
admin.site.register(Movies)